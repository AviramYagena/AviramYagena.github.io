/**
 * Experience component for the portfolio website.
 * Displays professional experience in a timeline format.
 */
export function Experience() {
  return (
    <section id="experience" className="border-t border-gray-800 bg-gradient-to-b from-gray-900 to-blue-900 py-20">
      <div className="container mx-auto px-4">
        <h2 className="mb-12 text-center text-4xl font-bold animate-fade-in-up">Professional Experience</h2>

        <div className="relative mx-auto max-w-4xl">
          {/* Timeline line */}
          <div className="absolute left-0 top-0 h-full w-0.5 bg-blue-600 md:left-1/2 md:-ml-0.5"></div>

          <ExperienceItem
            title="Risk Master Development"
            company="Self-employed"
            period="Jul 2024 - Present"
            description={[
              "Developed Risk Master, an advanced risk management tool for NinjaTrader",
              "Implemented customizable risk profiles and real-time protection features",
              "Built and maintained a user base of over 60 active traders",
              "Designed and implemented licensing, automated emailing, and support systems",
            ]}
            align="right"
          />

          <ExperienceItem
            title="AI-Driven Development"
            company="Self-employed"
            period="Feb 2024 - Jun 2024"
            description={[
              "Explored AI technologies for automation and intelligent systems",
              "Developed facial recognition systems for live stage performances",
              "Integrated computer vision libraries like OpenCV with Python",
              "Created AI-driven interactive experiences and games",
            ]}
            align="left"
          />

          <ExperienceItem
            title="Algorithmic Trading"
            company="Self-employed"
            period="Mar 2023 - Apr 2024"
            description={[
              "Developed and refined algorithmic trading strategies",
              "Created automated solutions for enhanced market performance and analysis",
              "Implemented over 10 algorithms with an 80% success rate",
              "Designed a comprehensive automated trade algorithm builder",
            ]}
            align="right"
          />

          <ExperienceItem
            title="Godot Game Development & Design"
            company="Self-employed"
            period="Nov 2019 - Mar 2023"
            description={[
              "Led the design and development of 4 full games using Godot Engine",
              "Exported games for multiple platforms: Android, iOS, PC, and Mac",
              "Developed skills in game mechanics, physics simulations, and AI-driven interactions",
              "Managed entire game development lifecycle from concept to release",
            ]}
            align="left"
          />
        </div>
      </div>
    </section>
  )
}

interface ExperienceItemProps {
  title: string
  company: string
  period: string
  description: string[]
  align: "left" | "right"
}

function ExperienceItem({ title, company, period, description, align }: ExperienceItemProps) {
  const isRight = align === "right"
  const animationDelay = isRight ? "" : "animation-delay-200"

  return (
    <div className={`relative mb-16 md:mb-0 ${isRight ? "" : "md:mt-16"} animate-fade-in-up ${animationDelay}`}>
      <div className="md:flex md:items-center">
        {isRight ? (
          <div className="mb-8 flex md:mb-0 md:w-1/2 md:justify-end md:pr-8">
            <ExperienceCard {...{ title, company, period, description }} />
          </div>
        ) : (
          <>
            <div className="hidden md:block md:w-1/2"></div>
            <div className="mb-8 flex md:mb-0 md:w-1/2 md:justify-start md:pl-8">
              <ExperienceCard {...{ title, company, period, description }} />
            </div>
          </>
        )}
        {!isRight && <div className="hidden md:block md:w-1/2"></div>}
      </div>
      <div className="absolute left-0 top-6 z-10 h-4 w-4 rounded-full bg-blue-600 md:left-1/2 md:-ml-2"></div>
    </div>
  )
}

function ExperienceCard({ title, company, period, description }: Omit<ExperienceItemProps, "align">) {
  return (
    <div className="relative z-10 rounded-lg bg-gray-800 p-6 shadow-xl">
      <h3 className="mb-2 text-2xl font-bold">{title}</h3>
      <p className="mb-2 text-blue-400">{company}</p>
      <p className="mb-4 text-sm text-gray-400">{period}</p>
      <ul className="list-inside list-disc space-y-2 text-gray-300">
        {description.map((item, index) => (
          <li key={index}>{item}</li>
        ))}
      </ul>
    </div>
  )
}

