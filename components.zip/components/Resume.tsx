import { Download } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"

/**
 * Resume component for the portfolio website.
 * Displays a summary of professional experience and skills.
 */
export function Resume() {
  return (
    <section id="resume" className="border-t border-gray-800 bg-gray-900 py-20">
      <div className="container mx-auto px-4">
        <h2 className="mb-12 text-center text-4xl font-bold animate-fade-in-up">Resume</h2>

        <div className="mx-auto max-w-4xl">
          <Card className="border-gray-700 bg-gray-800/50 p-8 backdrop-blur-sm animate-fade-in-up animation-delay-200">
            <div className="mb-8 text-center">
              <h3 className="text-2xl font-bold">Aviram Yagena</h3>
              <p className="text-blue-400">Developer & Trading Systems Specialist</p>
              <div className="mt-2 text-gray-400">
                <p>contact@example.com | LinkedIn: aviram-yagena-84942b23b</p>
              </div>
            </div>

            <ResumeSection
              title="Professional Summary"
              content="Self-taught developer with over 4 years of experience specializing in trading systems, game development, and AI integration. Proven track record in creating innovative solutions, from risk management tools to cross-platform games and AI-driven applications."
            />

            <ResumeSection
              title="Key Projects"
              content={[
                {
                  title: "Risk Master",
                  description: "Advanced risk management tool for NinjaTrader with 60+ active users.",
                },
                {
                  title: "Algorithmic Trading System",
                  description:
                    "Developed 10+ algorithms with an 80% success rate and created an automated trade algorithm builder.",
                },
                {
                  title: "Godot Game Development",
                  description: "Designed and developed 4 full games, exported for Android, iOS, PC, and Mac.",
                },
              ]}
            />

            <ResumeSection
              title="Skills"
              content={[
                {
                  title: "Trading Systems",
                  description: "NinjaTrader, Algorithmic Trading, Risk Management",
                },
                {
                  title: "Game Development",
                  description: "Godot Engine, Game Design, Cross-platform Development",
                },
                {
                  title: "Programming",
                  description: "C#, Python, GDScript, JavaScript/TypeScript",
                },
                {
                  title: "AI & Computer Vision",
                  description: "OpenCV, YOLO, Machine Learning Integration",
                },
              ]}
            />

            <ResumeSection
              title="Professional Experience"
              content={[
                {
                  title: "Risk Master Development",
                  description: "Jul 2024 - Present\nSelf-employed",
                },
                {
                  title: "AI-Driven Development",
                  description: "Feb 2024 - Jun 2024\nSelf-employed",
                },
                {
                  title: "Algorithmic Trading",
                  description: "Mar 2023 - Apr 2024\nSelf-employed",
                },
                {
                  title: "Godot Game Development & Design",
                  description: "Nov 2019 - Mar 2023\nSelf-employed",
                },
              ]}
            />
          </Card>

          <div className="mt-8 flex justify-center">
            <Button className="gap-2 animate-fade-in-up animation-delay-400">
              <Download className="h-4 w-4" />
              Download Full Resume
            </Button>
          </div>
        </div>
      </div>
    </section>
  )
}

interface ResumeSectionProps {
  title: string
  content: string | { title: string; description: string }[]
}

function ResumeSection({ title, content }: ResumeSectionProps) {
  return (
    <div className="mb-8">
      <h4 className="mb-4 text-xl font-semibold">{title}</h4>
      {typeof content === "string" ? (
        <p className="text-gray-300">{content}</p>
      ) : (
        <div className="grid gap-4 sm:grid-cols-2">
          {content.map((item, index) => (
            <div key={index}>
              <h5 className="mb-2 font-bold">{item.title}</h5>
              <p className="text-gray-300">{item.description}</p>
            </div>
          ))}
        </div>
      )}
    </div>
  )
}

