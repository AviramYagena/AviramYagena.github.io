import Link from "next/link"
import { Github, Linkedin, Mail } from "lucide-react"
import { Button } from "@/components/ui/button"

/**
 * Header component for the portfolio website.
 * Includes navigation links and social media buttons.
 */
export function Header() {
  return (
    <header className="sticky top-0 z-50 border-b border-gray-800 bg-gray-900/80 backdrop-blur-sm">
      <div className="container mx-auto flex h-16 items-center justify-between px-4">
        <div className="text-xl font-bold">Aviram Yagena</div>
        <nav className="hidden space-x-6 md:flex">
          <a href="#about" className="text-gray-300 hover:text-white transition-colors">
            About
          </a>
          <a href="#projects" className="text-gray-300 hover:text-white transition-colors">
            Projects
          </a>
          <a href="#experience" className="text-gray-300 hover:text-white transition-colors">
            Experience
          </a>
          <a href="#skills" className="text-gray-300 hover:text-white transition-colors">
            Skills
          </a>
          <a href="#resume" className="text-gray-300 hover:text-white transition-colors">
            Resume
          </a>
        </nav>
        <div className="flex space-x-2">
          <Button variant="outline" size="icon" asChild>
            <Link href="https://github.com/" target="_blank" rel="noopener noreferrer">
              <Github className="h-4 w-4" />
              <span className="sr-only">GitHub</span>
            </Link>
          </Button>
          <Button variant="outline" size="icon" asChild>
            <Link href="https://www.linkedin.com/in/aviram-yagena-84942b23b/" target="_blank" rel="noopener noreferrer">
              <Linkedin className="h-4 w-4" />
              <span className="sr-only">LinkedIn</span>
            </Link>
          </Button>
          <Button variant="outline" size="icon" asChild>
            <Link href="mailto:contact@example.com">
              <Mail className="h-4 w-4" />
              <span className="sr-only">Email</span>
            </Link>
          </Button>
        </div>
      </div>
    </header>
  )
}

