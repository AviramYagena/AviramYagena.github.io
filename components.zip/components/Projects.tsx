import { ExternalLink } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"

/**
 * Projects component for the portfolio website.
 * Displays notable projects and a game development showcase.
 */
export function Projects() {
  return (
    <section id="projects" className="border-t border-gray-800 bg-gray-900 py-20">
      <div className="container mx-auto px-4">
        <h2 className="mb-12 text-center text-4xl font-bold animate-fade-in-up">Notable Projects</h2>

        <div className="mx-auto grid max-w-6xl gap-8 md:grid-cols-2 lg:grid-cols-3">
          <ProjectCard
            title="Risk Master"
            description="Advanced risk management tool for NinjaTrader, providing real-time protection through customizable profiles and risk thresholds."
            features={[
              "60+ active users",
              "Automated emailing and ticketing system",
              "Custom licensing implementation",
            ]}
            tags={["NinjaTrader", "C#", "Risk Management"]}
            link="https://riskmaster.pro/"
          />

          <ProjectCard
            title="Algorithmic Trading System"
            description="Comprehensive automated trade algorithm builder based on a base strategy, finding optimal indicators and price action patterns."
            features={[
              "80% success rate across 10+ algorithms",
              "Continuous iteration on past market data",
              "AI-ready for future implementation",
            ]}
            tags={["NinjaTrader", "C#", "Algorithmic Trading"]}
          />

          <ProjectCard
            title="AI Interactive Game"
            description="Ongoing development of an AI-driven interactive game using computer vision libraries and advanced AI models."
            features={[
              "Utilizes OpenCV and YOLO",
              "Python and TouchDesigner integration",
              "Real-time object and person tracking",
            ]}
            tags={["Python", "OpenCV", "TouchDesigner", "AI"]}
          />
        </div>

        <GameDevelopmentShowcase />
      </div>
    </section>
  )
}

interface ProjectCardProps {
  title: string
  description: string
  features: string[]
  tags: string[]
  link?: string
}

function ProjectCard({ title, description, features, tags, link }: ProjectCardProps) {
  return (
    <Card className="flex h-full flex-col border-gray-700 bg-gray-800 animate-fade-in-up animation-delay-200">
      <div className="p-6">
        <h3 className="mb-2 text-xl font-bold">{title}</h3>
        <p className="mb-4 text-gray-300">{description}</p>
        <ul className="mb-4 list-inside list-disc text-gray-300">
          {features.map((feature, index) => (
            <li key={index}>{feature}</li>
          ))}
        </ul>
        <div className="mt-auto flex flex-wrap gap-2">
          {tags.map((tag, index) => (
            <Badge key={index} variant="secondary">
              {tag}
            </Badge>
          ))}
        </div>
        {link && (
          <div className="mt-4">
            <Button variant="outline" size="sm" asChild className="w-full">
              <a
                href={link}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center justify-center"
              >
                Visit Website
                <ExternalLink className="ml-2 h-4 w-4" />
              </a>
            </Button>
          </div>
        )}
      </div>
    </Card>
  )
}

function GameDevelopmentShowcase() {
  return (
    <div className="mt-12 animate-fade-in-up animation-delay-800">
      <h3 className="mb-6 text-center text-2xl font-bold">Game Development Showcase</h3>
      <div className="grid gap-8 md:grid-cols-2">
        {[1, 2, 3, 4].map((game) => (
          <div key={game} className="aspect-video w-full overflow-hidden rounded-lg bg-gray-800">
            <div className="flex h-full items-center justify-center">
              <p className="text-lg text-gray-400">Game {game} Video Placeholder</p>
            </div>
          </div>
        ))}
      </div>
      <p className="mt-4 text-center text-gray-400">
        Four full games developed and exported for Android, iOS, PC, and Mac using Godot Engine.
      </p>
    </div>
  )
}

