import { Card } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"

/**
 * Skills component for the portfolio website.
 * Displays skills and expertise in various areas.
 */
export function Skills() {
  return (
    <section id="skills" className="border-t border-gray-800 bg-blue-900 py-20">
      <div className="container mx-auto px-4">
        <h2 className="mb-12 text-center text-4xl font-bold animate-fade-in-up">Skills & Expertise</h2>

        <div className="mx-auto grid max-w-4xl gap-8 md:grid-cols-2">
          <SkillCard
            title="Trading Systems Development"
            skills={[
              "NinjaTrader Addon Development",
              "Algorithmic Trading System Design",
              "Risk Management Solutions",
              "Backtesting and Strategy Optimization",
            ]}
            animationDelay="animation-delay-200"
          />

          <SkillCard
            title="Game Development"
            skills={[
              "Godot Engine",
              "Game Design and Mechanics",
              "Cross-platform Development (Android, iOS, PC, Mac)",
              "AI-driven Game Systems",
            ]}
            animationDelay="animation-delay-400"
          />

          <SkillCard
            title="Programming Languages"
            skills={["C# (NinjaScript, .NET)", "Python", "GDScript (Godot)", "JavaScript/TypeScript"]}
            animationDelay="animation-delay-600"
          />

          <SkillCard
            title="AI and Computer Vision"
            skills={[
              "OpenCV",
              "YOLO (You Only Look Once)",
              "Machine Learning Integration",
              "Real-time Data Processing and Analysis",
            ]}
            animationDelay="animation-delay-800"
          />
        </div>

        <div className="mt-12 flex flex-wrap justify-center gap-2 animate-fade-in-up animation-delay-1000">
          {[
            "NinjaTrader",
            "Algorithmic Trading",
            "Risk Management",
            "Godot",
            "Game Development",
            "C#",
            "Python",
            "OpenCV",
            "AI Integration",
            "Full-Stack Development",
          ].map((skill, index) => (
            <Badge key={index} className="bg-blue-700 px-3 py-1 text-sm">
              {skill}
            </Badge>
          ))}
        </div>
      </div>
    </section>
  )
}

interface SkillCardProps {
  title: string
  skills: string[]
  animationDelay: string
}

function SkillCard({ title, skills, animationDelay }: SkillCardProps) {
  return (
    <Card className={`border-gray-700 bg-gray-800/50 p-6 backdrop-blur-sm animate-fade-in-up ${animationDelay}`}>
      <h3 className="mb-4 text-xl font-semibold">{title}</h3>
      <ul className="list-inside list-disc space-y-2 text-gray-300">
        {skills.map((skill, index) => (
          <li key={index}>{skill}</li>
        ))}
      </ul>
    </Card>
  )
}

