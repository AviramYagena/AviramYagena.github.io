import type React from "react"
import { Github, Linkedin, Mail } from "lucide-react"

/**
 * Footer component for the portfolio website.
 * Displays copyright information and social media links.
 */
export function Footer() {
  return (
    <footer className="border-t border-gray-800 bg-gray-900 py-8">
      <div className="container mx-auto px-4 text-center">
        <p className="text-gray-400">© {new Date().getFullYear()} Aviram Yagena. All rights reserved.</p>
        <div className="mt-4 flex justify-center space-x-4">
          <SocialLink href="https://github.com/" icon={Github} label="GitHub" />
          <SocialLink href="https://www.linkedin.com/in/aviram-yagena-84942b23b/" icon={Linkedin} label="LinkedIn" />
          <SocialLink href="mailto:contact@example.com" icon={Mail} label="Email" />
        </div>
      </div>
    </footer>
  )
}

interface SocialLinkProps {
  href: string
  icon: React.ElementType
  label: string
}

function SocialLink({ href, icon: Icon, label }: SocialLinkProps) {
  return (
    <a
      href={href}
      target="_blank"
      rel="noopener noreferrer"
      className="text-gray-400 hover:text-white transition-colors"
    >
      <Icon className="h-5 w-5" />
      <span className="sr-only">{label}</span>
    </a>
  )
}

