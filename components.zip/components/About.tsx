/**
 * About component for the portfolio website.
 * Provides a brief introduction and overview of skills and experience.
 */
export function About() {
  return (
    <section id="about" className="py-20">
      <div className="container mx-auto px-4">
        <h2 className="mb-12 text-center text-4xl font-bold animate-fade-in-up">About Me</h2>
        <div className="mx-auto max-w-3xl animate-fade-in-up animation-delay-200">
          <p className="mb-6 text-lg text-gray-300">
            As a self-taught developer with over 4 years of experience, I've honed my skills across multiple domains,
            including trading systems development, game design, and AI integration. My passion lies in creating
            innovative solutions that bridge complex algorithms with user-friendly experiences.
          </p>
          <p className="mb-6 text-lg text-gray-300">
            I specialize in developing cutting-edge trading systems and automating strategies for NinjaTrader, with a
            focus on risk management tools and algorithmic trading solutions. My experience extends to game development
            using Godot, where I've successfully created and launched multiple games across various platforms.
          </p>
          <p className="text-lg text-gray-300">
            Currently, I'm exploring the intersection of AI and interactive experiences, developing computer vision
            applications and pushing the boundaries of what's possible in game development and trading systems.
          </p>
        </div>
      </div>
    </section>
  )
}

