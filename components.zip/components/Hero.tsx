import { Button } from "@/components/ui/button"

/**
 * Hero component for the portfolio website.
 * Displays the main introduction and call-to-action buttons.
 */
export function Hero() {
  return (
    <section className="relative overflow-hidden bg-gradient-to-br from-blue-900 to-gray-900 py-24 md:py-32">
      <div className="container mx-auto px-4">
        <div className="text-center">
          <h1 className="mb-4 text-5xl font-bold leading-tight md:text-6xl animate-fade-in-up">Aviram Yagena</h1>
          <h2 className="mb-6 text-2xl font-medium text-blue-400 md:text-3xl animate-fade-in-up animation-delay-200">
            Developer & Trading Systems Specialist
          </h2>
          <p className="mb-8 text-lg text-gray-300 max-w-2xl mx-auto animate-fade-in-up animation-delay-400">
            Crafting innovative solutions in trading systems, game development, and AI integration.
          </p>
          <div className="flex flex-wrap justify-center gap-3 animate-fade-in-up animation-delay-600">
            <Button asChild>
              <a href="#projects">View Projects</a>
            </Button>
            <Button variant="outline" asChild>
              <a href="#contact">Contact Me</a>
            </Button>
          </div>
        </div>
      </div>
      <div className="absolute -bottom-16 left-0 right-0 h-32 bg-gray-900 [mask-image:linear-gradient(transparent,#111827)]"></div>
    </section>
  )
}

