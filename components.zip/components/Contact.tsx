import type React from "react"
import { Github, Linkedin, Mail } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"

/**
 * Contact component for the portfolio website.
 * Displays contact information and a contact form.
 */
export function Contact() {
  return (
    <section id="contact" className="border-t border-gray-800 bg-gradient-to-b from-blue-900 to-gray-900 py-20">
      <div className="container mx-auto px-4">
        <h2 className="mb-12 text-center text-4xl font-bold animate-fade-in-up">Get In Touch</h2>

        <div className="mx-auto grid max-w-4xl gap-8 md:grid-cols-2">
          <Card className="border-gray-700 bg-gray-800/50 p-6 backdrop-blur-sm animate-fade-in-up animation-delay-200">
            <h3 className="mb-4 text-xl font-semibold">Contact Information</h3>
            <div className="space-y-4">
              <ContactItem icon={Mail} text="contact@example.com" />
              <ContactItem
                icon={Linkedin}
                text="linkedin.com/in/aviram-yagena-84942b23b"
                link="https://www.linkedin.com/in/aviram-yagena-84942b23b/"
              />
              <ContactItem icon={Github} text="github.com/aviramyagena" link="https://github.com/" />
            </div>
          </Card>

          <Card className="border-gray-700 bg-gray-800/50 p-6 backdrop-blur-sm animate-fade-in-up animation-delay-400">
            <h3 className="mb-4 text-xl font-semibold">Send a Message</h3>
            <form className="space-y-4">
              <FormField label="Name" id="name" type="text" placeholder="Your name" />
              <FormField label="Email" id="email" type="email" placeholder="Your email" />
              <FormField label="Message" id="message" type="textarea" placeholder="Your message" />
              <Button type="submit" className="w-full">
                Send Message
              </Button>
            </form>
          </Card>
        </div>
      </div>
    </section>
  )
}

interface ContactItemProps {
  icon: React.ElementType
  text: string
  link?: string
}

function ContactItem({ icon: Icon, text, link }: ContactItemProps) {
  return (
    <div className="flex items-center gap-3">
      <Icon className="h-5 w-5 text-blue-400" />
      {link ? (
        <a href={link} target="_blank" rel="noopener noreferrer" className="hover:text-blue-400">
          {text}
        </a>
      ) : (
        <p>{text}</p>
      )}
    </div>
  )
}

interface FormFieldProps {
  label: string
  id: string
  type: string
  placeholder: string
}

function FormField({ label, id, type, placeholder }: FormFieldProps) {
  return (
    <div className="space-y-2">
      <label htmlFor={id} className="block text-sm font-medium text-gray-300">
        {label}
      </label>
      {type === "textarea" ? (
        <textarea
          id={id}
          rows={4}
          placeholder={placeholder}
          className="w-full rounded-md border border-gray-700 bg-gray-800 p-2 text-white placeholder:text-gray-500 focus:border-blue-500 focus:outline-none focus:ring-1 focus:ring-blue-500"
        ></textarea>
      ) : (
        <input
          id={id}
          type={type}
          placeholder={placeholder}
          className="w-full rounded-md border border-gray-700 bg-gray-800 p-2 text-white placeholder:text-gray-500 focus:border-blue-500 focus:outline-none focus:ring-1 focus:ring-blue-500"
        />
      )}
    </div>
  )
}

